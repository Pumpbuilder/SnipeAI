# pump-bot
build pump bot for AI tokens


